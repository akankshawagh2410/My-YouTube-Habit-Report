
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st
from collections import Counter
import re

st.set_page_config(page_title="YouTube Watch History Dashboard", layout="wide")

YOUTUBE_RED = "#FF0000"

def yt_bar(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_title(ax.get_title(), fontsize=16, fontweight="bold", color="#282828")

st.title("📺 YouTube Watch History Dashboard")
uploaded_file = st.file_uploader("Upload your watch-history.json from Google Takeout", type="json")

if uploaded_file:
    data = json.load(uploaded_file)

    # Parse JSON from Google Takeout
    records = []
    for item in data:
        if "title" in item and "time" in item:
            records.append({
                "title": item.get("title"),
                "video_url": item.get("titleUrl"),
                "channel": item.get("subtitles", [{}])[0].get("name"),
                "watched_at": pd.to_datetime(item.get("time")),
                "platform": ", ".join(item.get("products", []))
            })
    df = pd.DataFrame(records)

    if df.empty:
        st.error("No watch records found in this file.")
        st.stop()

    # Time features
    df["date"] = df["watched_at"].dt.date
    df["hour"] = df["watched_at"].dt.hour
    df["month"] = df["watched_at"].dt.to_period("M")
    df["year"] = df["watched_at"].dt.year
    df["weekday"] = df["watched_at"].dt.day_name()

    st.success(f"✅ Loaded {len(df):,} watch records  |  {df['date'].min()} → {df['date'].max()}")

    # Filters
    with st.expander("Filters"):
        years = sorted(df["year"].unique().tolist())
        sel_years = st.multiselect("Year(s)", years, default=years)
        channels = sorted(df["channel"].dropna().unique().tolist())
        sel_channels = st.multiselect("Channel(s)", channels, default=[])

    fdf = df[df["year"].isin(sel_years)]
    if sel_channels:
        fdf = fdf[fdf["channel"].isin(sel_channels)]

    # KPIs
    total_videos = len(fdf)
    total_days = fdf["date"].nunique()
    top_channel = fdf["channel"].value_counts().idxmax() if total_videos else "—"
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Videos Watched", f"{total_videos:,}")
    col2.metric("Unique Days Active", f"{total_days:,}")
    col3.metric("Top Channel", top_channel)

    # Layout tabs
    tab_overview, tab_time, tab_binge, tab_keywords, tab_hidden = st.tabs(
        ["Overview", "Time Patterns", "Binge & Top Creators", "Keywords", "Hidden Habits"]
    )

    with tab_overview:
        st.subheader("🎯 Top 10 Channels by Views")
        top_channels = fdf["channel"].value_counts().head(10)
        fig, ax = plt.subplots(figsize=(10, 5))
        top_channels.plot(kind="bar", color=YOUTUBE_RED, edgecolor="black", ax=ax)
        ax.set_title("Top 10 Channels by Views")
        ax.set_xlabel("Channel"); ax.set_ylabel("Views")
        plt.xticks(rotation=45, ha="right")
        for i, v in enumerate(top_channels):
            ax.text(i, v + max(top_channels)*0.01, f"{v:,}", ha="center", fontsize=9)
        yt_bar(ax)
        st.pyplot(fig)

    with tab_time:
        st.subheader("📅 Monthly Watch History")
        monthly_counts = fdf.groupby("month").size()
        fig, ax = plt.subplots(figsize=(10,5))
        monthly_counts.plot(kind="line", marker="o", color=YOUTUBE_RED, linewidth=2, ax=ax)
        ax.set_title("Monthly YouTube Watch History")
        ax.set_xlabel("Month"); ax.set_ylabel("Views")
        plt.xticks(rotation=45)
        yt_bar(ax)
        st.pyplot(fig)

        st.subheader("⏰ Watching Activity by Hour")
        hourly_counts = fdf.groupby("hour").size()
        fig, ax = plt.subplots(figsize=(10,5))
        hourly_counts.plot(kind="bar", color=YOUTUBE_RED, edgecolor="black", ax=ax)
        ax.set_title("YouTube Activity by Hour")
        ax.set_xlabel("Hour of Day"); ax.set_ylabel("Views")
        plt.xticks(rotation=0)
        yt_bar(ax)
        st.pyplot(fig)

        st.subheader("📆 Most Watched Days of the Week")
        weekday_counts = fdf["weekday"].value_counts()
        fig, ax = plt.subplots(figsize=(10,5))
        weekday_counts.plot(kind="bar", color=YOUTUBE_RED, edgecolor="black", ax=ax)
        ax.set_title("Most Watched Days")
        plt.xticks(rotation=30)
        yt_bar(ax)
        st.pyplot(fig)

        st.subheader("🔥 Heatmap: Watch Activity by Day & Hour")
        heatmap_data = fdf.groupby(["weekday", "hour"]).size().unstack(fill_value=0)
        fig, ax = plt.subplots(figsize=(12,6))
        sns.heatmap(heatmap_data, cmap="Reds", ax=ax)
        ax.set_title("YouTube Watch Heatmap (Day vs Hour)")
        st.pyplot(fig)

    with tab_binge:
        st.subheader("🍿 Longest Binge Day")
        daily_counts = fdf.groupby("date").size()
        if not daily_counts.empty:
            longest_day = daily_counts.idxmax()
            st.write(f"**Your biggest binge day was {longest_day} with {daily_counts.max()} videos.**")

            day_df = fdf[fdf["date"] == longest_day]
            creator_counts = day_df["channel"].value_counts()
            if not creator_counts.empty:
                max_watches = creator_counts.max()
                top_creators = creator_counts[creator_counts == max_watches]
                st.write("**Top creator(s) on that day:**")
                for c, n in top_creators.items():
                    st.write(f"- {c}: {n} videos")

                fig, ax = plt.subplots(figsize=(8,5))
                creator_counts.plot(kind="bar", color=YOUTUBE_RED, edgecolor="black", ax=ax)
                ax.set_title(f"Creators Watched on {longest_day}")
                plt.xticks(rotation=45, ha="right")
                yt_bar(ax)
                st.pyplot(fig)

        st.subheader("⏱️ Binge Transitions (<30 mins apart)")
        sdf = fdf.sort_values("watched_at").copy()
        sdf["time_diff"] = sdf["watched_at"].diff().dt.total_seconds().div(60)
        binge_transitions = sdf[sdf["time_diff"] < 30].shape[0]
        st.write(f"🔥 **{binge_transitions} binge transitions** (videos started within 30 minutes of the previous one).")

    with tab_keywords:
        st.subheader("🔍 Top Keywords in Titles")
        words = []
        for title in fdf["title"]:
            words.extend(re.findall(r'\w+', str(title).lower()))
        stop = set(\"\"\"a an the and or of to in on for with from is are was were be been
                       this that those these my your our their it its you me we they\"\"\".split())
        filtered = [w for w in words if w not in stop and len(w) > 2]
        common_words = Counter(filtered).most_common(20)
        if common_words:
            word_df = pd.DataFrame(common_words, columns=["Keyword", "Count"])
            fig, ax = plt.subplots(figsize=(10,5))
            word_df.set_index("Keyword")["Count"].plot(kind="bar", color=YOUTUBE_RED, edgecolor="black", ax=ax)
            ax.set_title("Top 20 Keywords in Video Titles")
            plt.xticks(rotation=45, ha="right")
            yt_bar(ax)
            st.pyplot(fig)
        else:
            st.info("No keywords to display.")

    with tab_hidden:
        st.subheader("🌙 Hidden Habit: Late-Night Creators (11 PM – 3 AM)")
        late_night_df = fdf[(fdf["hour"] >= 23) | (fdf["hour"] <= 3)]
        if late_night_df.empty:
            st.info("No late-night views found for the selected filters.")
        else:
            late_night_creators = late_night_df["channel"].value_counts().head(10)
            fig, ax = plt.subplots(figsize=(10,6))
            late_night_creators.plot(kind="barh", color=YOUTUBE_RED, edgecolor="black", ax=ax)
            ax.set_title("Top 10 Late-Night Creators (11 PM – 3 AM)")
            ax.set_xlabel("Views"); ax.set_ylabel("Channel")
            ax.invert_yaxis()
            for i, v in enumerate(late_night_creators):
                ax.text(v + max(late_night_creators)*0.01, i, f"{v:,}", va="center", fontsize=10)
            yt_bar(ax)
            st.pyplot(fig)

else:
    st.info("👆 Upload your `watch-history.json` to see your stats!")
