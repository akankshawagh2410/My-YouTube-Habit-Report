
import json
import pandas as pd
from dash import Dash, dcc, html, Input, Output, State
import plotly.express as px

app = Dash(__name__)
app.title = "YouTube Watch History (Dash)"

app.layout = html.Div([
    html.H2("📺 YouTube Watch History Dashboard (Dash)"),
    dcc.Upload(
        id='upload-data',
        children=html.Div(['Drag and Drop or ', html.A('Select watch-history.json')]),
        multiple=False,
        style={'width': '100%', 'height': '60px', 'lineHeight': '60px',
               'borderWidth': '1px', 'borderStyle': 'dashed',
               'borderRadius': '5px', 'textAlign': 'center', 'margin': '10px'}
    ),
    html.Div(id='kpi'),
    dcc.Dropdown(id="year-filter", multi=True, placeholder="Filter by year"),
    dcc.Dropdown(id="channel-filter", multi=True, placeholder="Filter by channel"),
    dcc.Graph(id='top-channels'),
    dcc.Graph(id='monthly'),
    dcc.Graph(id='hourly'),
    dcc.Graph(id='weekday'),
    dcc.Graph(id='heatmap'),
    dcc.Graph(id='late-night')
])

@app.callback(
    Output('kpi', 'children'),
    Output('year-filter', 'options'),
    Output('channel-filter', 'options'),
    Output('top-channels', 'figure'),
    Output('monthly', 'figure'),
    Output('hourly', 'figure'),
    Output('weekday', 'figure'),
    Output('heatmap', 'figure'),
    Output('late-night', 'figure'),
    Input('upload-data', 'contents'),
    State('upload-data', 'filename')
)
def update(contents, filename):
    if contents is None:
        return "Upload your JSON file to begin.", [], [], {}, {}, {}, {}, {}, {}

    import base64, io, json
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    data = json.load(io.BytesIO(decoded))

    records = []
    for item in data:
        if "title" in item and "time" in item:
            records.append({
                "title": item.get("title"),
                "video_url": item.get("titleUrl"),
                "channel": item.get("subtitles", [{}])[0].get("name"),
                "watched_at": pd.to_datetime(item.get("time")),
                "platform": ", ".join(item.get("products", []))
            })
    df = pd.DataFrame(records)
    if df.empty:
        return "No records found.", [], [], {}, {}, {}, {}, {}, {}

    df["date"] = df["watched_at"].dt.date
    df["hour"] = df["watched_at"].dt.hour
    df["month"] = df["watched_at"].dt.to_period("M").astype(str)
    df["year"] = df["watched_at"].dt.year.astype(str)
    df["weekday"] = df["watched_at"].dt.day_name()

    kpi = html.Div([
        html.Div(f"Loaded {len(df):,} records | {df['date'].min()} → {df['date'].max()}")
    ])

    years = [{'label': y, 'value': y} for y in sorted(df['year'].unique().tolist())]
    channels = [{'label': c, 'value': c} for c in sorted(df['channel'].dropna().unique().tolist())]

    # Top channels
    top = df['channel'].value_counts().head(10).reset_index()
    top.columns = ['channel', 'count']
    fig_top = px.bar(top, x='channel', y='count', title='Top 10 Channels by Views')
    fig_top.update_traces(marker_color='#FF0000')
    fig_top.update_layout(xaxis_tickangle=45)

    # Monthly
    monthly = df.groupby('month').size().reset_index(name='count')
    fig_month = px.line(monthly, x='month', y='count', title='Monthly YouTube Watch History')

    # Hourly
    hourly = df.groupby('hour').size().reset_index(name='count')
    fig_hour = px.bar(hourly, x='hour', y='count', title='YouTube Activity by Hour')
    fig_hour.update_traces(marker_color='#FF0000')

    # Weekday
    weekday = df['weekday'].value_counts().reset_index()
    weekday.columns = ['weekday', 'count']
    fig_weekday = px.bar(weekday, x='weekday', y='count', title='Most Watched Days')
    fig_weekday.update_traces(marker_color='#FF0000')

    # Heatmap
    mat = df.groupby(['weekday','hour']).size().reset_index(name='count')
    fig_heat = px.density_heatmap(mat, x='hour', y='weekday', z='count', title='Watch Heatmap (Day vs Hour)', nbinsx=24)

    # Late night
    ln = df[(df['hour']>=23) | (df['hour']<=3)]
    ln_top = ln['channel'].value_counts().head(10).reset_index()
    ln_top.columns = ['channel','count']
    fig_ln = px.bar(ln_top, x='count', y='channel', orientation='h', title='Top Late-Night Creators (11 PM – 3 AM)')
    fig_ln.update_traces(marker_color='#FF0000')

    return kpi, years, channels, fig_top, fig_month, fig_hour, fig_weekday, fig_heat, fig_ln

if __name__ == "__main__":
    app.run_server(debug=True)
